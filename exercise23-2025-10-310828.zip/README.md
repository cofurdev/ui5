## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Fri Oct 31 2025 15:51:46 GMT+0900 (Korean Standard Time)|
|**App Generator**<br>SAP Fiori Application Generator|
|**App Generator Version**<br>1.19.3|
|**Generation Platform**<br>Visual Studio Code|
|**Template Used**<br>Basic V2|
|**Service Type**<br>OData URL|
|**Service URL**<br>https://services.odata.org/V2/Northwind/Northwind.svc|
|**Module Name**<br>exercise23|
|**Application Title**<br>UX400 Unit13 Exercise23 Add an OData Model to the Application|
|**Namespace**<br>code.d19|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.120.39|
|**Enable Code Assist Libraries**<br>False|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|

## exercise23

An SAP Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  To launch the generated application, run the following from the generated application root folder:

```
    npm start
```

- It is also possible to run the application using mock data that reflects the OData Service URL supplied during application generation.  In order to run the application with Mock Data, run the following from the generated app root folder:

```
    npm run start-mock
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


