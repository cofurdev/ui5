/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code/d19/exercise23/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
