sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
], (Controller, JSONModel) => {
    "use strict";

    return Controller.extend("code.d19.excode.controller.Main", {
        onInit() {
            var oData = {
                Carriers:[

                ]
            };
            var oModel = new JSONModel(oData);

            var oView = this.getView();
            oView.setModel(oModel,"view");
        },
        onAddButton(){
            // alert("dddd");
            this.pDialog ??=this.loadFragment({
                name: "code.d19.excode.view.Dialog"
            });

            this.pDialog.then((oDialog) => oDialog.open());

        },
        onOkButton(){
            var oView = this.getView();
            var oModel = oView.getModel("view");
            
            var oTable = oView.byId("idTable");
            var oSelectedItem = oTable.getSelectedItem();
            var oContext = oSelectedItem.getBindingContext();
            var oNewdata = oContext.getObject();
            var aData = oModel.getProperty("/Carriers");
            aData.push(oNewdata);
            
            oModel.setProperty("/Carriers", aData);


        
        },
        onCloseButton(){
            let oDialog = this.byId("idDialog");
            if(oDialog){
                oDialog.close();
            }
        },
        onDeleteButton(){
            alert("dddd");
        }
    });
});