## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Tue Oct 28 2025 16:15:29 GMT+0900 (Korean Standard Time)|
|**App Generator**<br>SAP Fiori Application Generator|
|**App Generator Version**<br>1.19.3|
|**Generation Platform**<br>Visual Studio Code|
|**Template Used**<br>Basic|
|**Service Type**<br>None|
|**Service URL**<br>N/A|
|**Module Name**<br>exercise10|
|**Application Title**<br>UX400 Unit8 Exercise 10 Add a UI with a Form|
|**Namespace**<br>code.d19|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.120.38|
|**Enable Code Assist Libraries**<br>False|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|

## exercise10

An SAP Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  To launch the generated application, run the following from the generated application root folder:

```
    npm start
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


