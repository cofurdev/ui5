## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Thu Oct 30 2025 11:48:50 GMT+0900 (Korean Standard Time)|
|**App Generator**<br>SAP Fiori Application Generator|
|**App Generator Version**<br>1.19.3|
|**Generation Platform**<br>Visual Studio Code|
|**Template Used**<br>Basic|
|**Service Type**<br>None|
|**Service URL**<br>N/A|
|**Module Name**<br>exercise16|
|**Application Title**<br>UX400 Unit 10 Exercise 16 Work with Data Types|
|**Namespace**<br>code.d19|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.120.39|
|**Enable Code Assist Libraries**<br>False|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|

## exercise16

An SAP Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  To launch the generated application, run the following from the generated application root folder:

```
    npm start
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


