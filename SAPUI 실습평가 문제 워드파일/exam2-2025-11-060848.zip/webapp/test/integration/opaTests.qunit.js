/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["code/d19/exam2/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
