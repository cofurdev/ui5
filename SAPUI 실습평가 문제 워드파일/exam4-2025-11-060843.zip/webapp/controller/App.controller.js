sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("code.d19.exam4.controller.App", {
      onInit() {
      }
  });
});