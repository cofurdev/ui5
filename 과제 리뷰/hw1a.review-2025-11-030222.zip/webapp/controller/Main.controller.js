sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/ui/model/json/JSONModel"
], (Controller, MessageToast, JSONModel) => {
    "use strict";

    return Controller.extend("code.d00.hw1a.review.controller.Main", {
        onInit() {
            // JSON Model을 생성하고, View의 기본모델 설정
            // 기본모델 = 별도의 이름을 가지지 않았다.
            let oModel = new JSONModel();
            let oView = this.getView();
            oView.setModel(oModel);
        },

        onClickButton(){
            // view의 버튼에서 취급하는 기능으로 잘 연결이 되었는지,
            // 확인하는 목적으로 alert를 사용했다.
            // alert("a");

            // byId를 너무 자주 쓰니깐, View가 아니라,
            // this에서 바로 사용할 수 있도록 기능이 추가되었다.
            // let oInput = this.byId("idInput");
            let oView = this.getView();
            let oInput = oView.byId("idInput");

            let sValue = oInput.getValue();

            MessageToast.show(sValue);

        },

        onClickJsonButton(){
            // alert('a');

            // 현재 화면의 기본모델을 가져온다.
            let oView = this.getView();
            let oModel = oView.getModel();

            // 모델의 getProperty 함수는 전달받은 경로에 대한 값을 가져온다.
            let sValue = oModel.getProperty("/Value");
            MessageToast.show(sValue);
        }
    });
});