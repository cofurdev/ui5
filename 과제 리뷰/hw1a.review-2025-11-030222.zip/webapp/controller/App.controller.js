sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("code.d00.hw1a.review.controller.App", {
      onInit() {
      }
  });
});