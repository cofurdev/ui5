sap.ui.define([
	"code/d00/hw1a/review/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
